
//ProjectIdentifier:​9B734EC0C043C5A836EA0EBE4BEFEA164490B2C7
#include "venting.h"
#include <limits>
#include <cmath>
#include <algorithm>
#include <vector>
#include <stack>

using namespace std;

void Vent::get_options(int argc, char** argv) {
    int option_index = 0, option = 0;
    opterr = false;
    struct option longOpts[] = {{ "mode", required_argument, nullptr, 'm' },
                                { "help", no_argument, nullptr, 'h' },
                                { nullptr, 0, nullptr, '\0' }
    };
    while ((option = getopt_long(argc, argv, "m:h",
                                 longOpts, &option_index)) != -1) {
        switch (option) {
            case 'm':
                mode = optarg;
                break;
            case 'h':
                std::cout << "HELP: Among us programs!!" << std::endl;
                exit(0);
        }
    }
    if (mode!= "MST" && mode != "OPTTSP" && mode != "FASTTSP"){
        cerr << "mode argument wrong!\n";
        exit(1);
    }
}

void Vent::read_data(istream &is){
    is >> num_rooms;
    for (int i = 0; i < (int) num_rooms ; ++i){
        Point room;
        is >> room.x >> room.y;
        if ((room.x == 0 && room.y < 0) || (room.x < 0 && room.y == 0)){
            room.type = 'd'; // decontamination room
            havedecon = true;
        } else if (room.x < 0 && room.y < 0){
            room.type = 'l'; // lab
            havelab = true;
        } else {
            room.type = 'o'; // outer area
            haveout = true;
        }
        rooms.push_back(room);
    }
}
size_t Vent::findMinCost(){
    size_t rtn = 0;
    double min = cost[0];
    for (size_t i = 1; i < cost.size(); ++i){
        if(!known[i] && min > cost[i]){
            min = cost[i];
            rtn = i;
        }
    }
    return rtn;
}
void Vent::prim (){
    while(find(known.begin(), known.end(), false) != known.end()){
        size_t current = findMinCost();
        known[current] = true;
        for (size_t i = 0; i < rooms.size(); ++i){
            double distance = dist(rooms[current], rooms[i]);
            if (!known[i] && distance < cost[i]){
                if (cost[i] !=  numeric_limits<double>::infinity()){
                    length -= cost[i];
                }
                length += distance;
                cost[i] = distance;
                connection[i] = current;
            }
        }
    }
    lowerbound = length;
}


double Vent::dist (Point& a, Point& b){
    if (mode == "MST"){
        if ((a.type == 'l' && b.type == 'o')
            || (a.type =='o' && b.type == 'l')){
            return numeric_limits<double>::infinity();
        }
    }
    long int x_diff =  abs(a.x - b.x);
    long int y_diff =  abs(a.y - b.y);
    return sqrt(x_diff * x_diff + y_diff * y_diff);
}

double Vent::totallength(vector<size_t> &con){
    double rtn = totallength(con, con.size());
    rtn += dist(rooms[con[con.size() - 1]], rooms[con[0]]);
    return rtn;
}
double Vent::totallength(vector<size_t> &con, size_t l){
    double rtn = 0;
    for (size_t i = 0; i < l - 1; ++i){
        rtn += dist(rooms[con[i]], rooms[con[i + 1]]);
    }
    return rtn;
}

bool Vent::promising(vector<size_t> &path, size_t permLength){
    if (permLength < path.size() - 4){
        return true;
    }
    if (totallength(path, permLength) > upperbound){
        return false;
    }
    return true;
}
void insertat (vector<size_t> &con, const size_t index, size_t val){
    for (size_t i = con.size() - 1; i > index; --i){
        con[i] = con[i - 1];
    }
    con[index] = val;
}

void Vent::genPerms(vector<size_t> &path, size_t permLength) {
     if (permLength == path.size()) {
         double len = totallength(path);
         if ( len < length){
             route = path;
             length = len;
         }
         return;
     } // if
    if (!promising(path, permLength)){
        return;
    }
     for (size_t i = permLength; i < path.size(); ++i) {
       swap(path[permLength], path[i]);
       genPerms(path, permLength + 1);
       swap(path[permLength], path[i]);
     } // for
} // genPerms()

// THIS IS CLOSEST INSERTION AND FURTHEST INSERTION
void Vent::fasttsp(){
    route[0] = 0;
    route[1] = 1;
    route[2] = 2;
    size_t sz = 3;
    known[0] = true;
    known[1] = true;
    known[2] = true;
    length += dist(rooms[0], rooms[1]) + dist(rooms[1], rooms[2]) + dist(rooms[2], rooms[0]);
    for (size_t i = 3; i < rooms.size(); ++i){
        double curmin = numeric_limits<double>::infinity();
        size_t insertatin = 0;
        for (size_t j = 0; j < sz; ++j){
            double originalEdge = dist(rooms[route[j]], rooms [route[(j + 1) % sz]]);
            double addeddis = dist(rooms[route[j]], rooms[i]) + dist(rooms[route[(j + 1) % sz]], rooms[i]);
            if ( addeddis - originalEdge < curmin){
                insertatin = (j + 1) % sz;
                curmin = addeddis - originalEdge;
            }
        }
        length += curmin;
        insertat(route, insertatin, i);
        ++sz;
    }
    upperbound = length;
}
void Vent::opttsp(){
    fasttsp();
    vector<size_t> path ((size_t)num_rooms);
    for (size_t i = 0; i < path.size(); ++i){
        path[i] = i;
    }
    route = path;
    genPerms(path, 1);
}

void Vent::run(int argc, char**argv){
    get_options(argc, argv);
    read_data(cin);
    if (mode == "MST" && haveout && havelab && !havedecon){
        cerr << "Cannot construct MST\n";
        exit(1);
    }
    cost.resize((size_t)num_rooms);
    fill(cost.begin(), cost.end(), numeric_limits<double>::infinity());
    known.resize((size_t)num_rooms);
    fill(known.begin(), known.end(), false);
    connection.resize((size_t)num_rooms);
    route.resize((size_t)num_rooms);
    if (mode == "MST"){
        prim();
        cout << length <<"\n";
        for (size_t i = 1; i < connection.size(); ++i){
            if (i > connection [i]){
                cout<< connection [i] << " "  << i <<"\n";
            } else {
                cout << i << " " << connection [i]<<"\n";
            }
        }
    } else {
        if (mode == "FASTTSP"){
            fasttsp();
        } else if (mode == "OPTTSP"){
            opttsp();
        }
        cout << length <<"\n";
        size_t print0 = 0;
        while(route[print0] != 0){
            ++print0;
        }
        for (size_t i = 0; i < route.size(); ++i){
            cout << route[(i + print0) % route.size()] <<" ";
        }
        cout << "\n";
    }
}


