
//ProjectIdentifier:​9B734EC0C043C5A836EA0EBE4BEFEA164490B2C7
#ifndef VENTING_H
#define VENTING_H

#include <stdio.h>
#include <sstream>
#include <iostream>
#include <array>
#include <getopt.h>
#include <queue>
#include <deque>
#include <vector>


using namespace std;

// This file is posted here so that you can easily copy/paste the code.
// It's unsafe to copy/paste from PDF files, due to hidden characters.



class Vent{

public:
    struct Point{
        long int x;
        long int y;
        char type;
    };
    
    void get_options(int argc, char** argv);
    void run(int argc, char**argv);
    void read_data (istream& is);
    double dist (Point& a, Point& b);
//    double euclidean(Point &a, Point &b);
    void prim ();
    void fasttsp();
//    void printpath();
    bool promising(vector<size_t> &path, size_t permLength);
    void genPerms(vector<size_t> &path, size_t permLength);
    
private:
//    double closestPoint (size_t index, size_t &rtn);
//    size_t closestPoint (const size_t index);
    bool haveout = false;
    bool havelab = false;
    bool havedecon = false;
    int num_rooms;
    vector<Point> rooms;
    string mode;
    vector <bool> known;
    vector<double> cost;
    vector<size_t> connection;
    size_t findMinCost ();
    
    double length = 0;
    vector<size_t> route;
    double totallength(vector<size_t> &con);
    double totallength(vector<size_t> &con, size_t l);
    vector<size_t> twoOptSwap(size_t i, size_t k);
    
    void opttsp();
    double upperbound;
    double lowerbound;
};
#endif // venting.h
