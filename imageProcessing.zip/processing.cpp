// Project UID af1f95f547e44c8ea88730dfb185559d

#include <cassert>
#include "processing.h"

// v DO NOT CHANGE v ------------------------------------------------
// The implementation of rotate_left is provided for you.
// REQUIRES: img points to a valid Image
// MODIFIES: *img
// EFFECTS:  The image is rotated 90 degrees to the left (counterclockwise).
void rotate_left(Image* img) {

  // for convenience
  int width = Image_width(img); 
  int height = Image_height(img);

  // auxiliary image to temporarily store rotated image
  Image *aux = new Image;
  Image_init(aux, height, width); // width and height switched

  // iterate through pixels and place each where it goes in temp
  for (int r = 0; r < height; ++r) {
    for (int c = 0; c < width; ++c) {
      Image_set_pixel(aux, width - 1 - c, r, Image_get_pixel(img, r, c));
    }
  }

  // Copy data back into original
  *img = *aux;
  delete aux;
}
// ^ DO NOT CHANGE ^ ------------------------------------------------

// v DO NOT CHANGE v ------------------------------------------------
// The implementation of rotate_right is provided for you.
// REQUIRES: img points to a valid Image.
// MODIFIES: *img
// EFFECTS:  The image is rotated 90 degrees to the right (clockwise).
void rotate_right(Image* img){

  // for convenience
  int width = Image_width(img);
  int height = Image_height(img);
    

  // auxiliary image to temporarily store rotated image
  Image *aux = new Image;
  Image_init(aux, height, width); // width and height switched

  // iterate through pixels and place each where it goes in temp
  for (int r = 0; r < height; ++r) {
    for (int c = 0; c < width; ++c) {
      Image_set_pixel(aux, c, height - 1 - r, Image_get_pixel(img, r, c));
    }
  }

  // Copy data back into original
  *img = *aux;
  delete aux;
}
// ^ DO NOT CHANGE ^ ------------------------------------------------


void greyscale(Image *img){
    // for convenience
    int width = Image_width(img);
    int height = Image_height(img);
    Image *aux = new Image;
    Image_init(aux, width, height);
    for (int r = 0; r < height; ++r) {
      for (int c = 0; c < width; ++c) {
          Pixel grey = Image_get_pixel(img, r, c);
          Pixel sep;
          sep.r = grey.r * 1/3 + grey.g * 1/3 + grey.b * 1/3;
          sep.g = grey.r * 1/3 + grey.g * 1/3 + grey.b * 1/3;
          sep.b = grey.r * 1/3 + grey.g * 1/3 + grey.b * 1/3;
        Image_set_pixel(aux, r, c, sep);
          
      }
    }
    *img = *aux;
    delete aux;
}

void b(Image *img){
    // for convenience
    int width = Image_width(img);
    int height = Image_height(img);
    Image *aux = new Image;
    Image_init(aux, width, height);
    for (int r = 0; r < height; ++r) {
      for (int c = 0; c < width; ++c) {
          Pixel grey = Image_get_pixel(img, r, c);
          grey.b = grey.b + 50;
        Image_set_pixel(aux, r, c, grey);
      }
    }
    *img = *aux;
    delete aux;
}

void r(Image *img){
    // for convenience
    int width = Image_width(img);
    int height = Image_height(img);
    Image *aux = new Image;
    Image_init(aux, width, height);
    for (int r = 0; r < height; ++r) {
      for (int c = 0; c < width; ++c) {
          Pixel grey = Image_get_pixel(img, r, c);
          grey.r = grey.r + 50;
        Image_set_pixel(aux, r, c, grey);
      }
    }
    *img = *aux;
    delete aux;
}

void g(Image *img){
    // for convenience
    int width = Image_width(img);
    int height = Image_height(img);
    Image *aux = new Image;
    Image_init(aux, width, height);
    for (int r = 0; r < height; ++r) {
      for (int c = 0; c < width; ++c) {
          Pixel grey = Image_get_pixel(img, r, c);
          grey.g = grey.g + 50;
        Image_set_pixel(aux, r, c, grey);
      }
    }
    *img = *aux;
    delete aux;
}

void sepian (Image *img){
    /*0.393    0.769    0.189
     0.349    0.686    0.168
     0.272    0.534    0.131*/
    int width = Image_width(img);
    int height = Image_height(img);
    Image *aux = new Image;
    Image_init(aux, width, height);
    for (int r = 0; r < height; ++r) {
      for (int c = 0; c < width; ++c) {
          Pixel grey = Image_get_pixel(img, r, c);
          Pixel sep;
          sep.r = grey.r * 0.393 + grey.g * 0.349 + grey.b * 0.272;
          sep.g = grey.r * 0.769 + grey.g * 0.686 + grey.b * 0.534;
          sep.b = grey.r * 0.189 + grey.g * 0.168 + grey.b * 0.131;
        Image_set_pixel(aux, r, c, sep);
      }
    }
    *img = *aux;
    delete aux;
}

void negative (Image *img){
    int width = Image_width(img);
    int height = Image_height(img);
    Image *aux = new Image;
    Image_init(aux, width, height);
    for (int r = 0; r < height; ++r) {
      for (int c = 0; c < width; ++c) {
          Pixel grey = Image_get_pixel(img, r, c);
          grey.b = (grey.b - 255);
          grey.r = (grey.r - 255);
          grey.g = (grey.g - 255);
        Image_set_pixel(aux, r, c, grey);
      }
    }
    *img = *aux;
    delete aux;
}
