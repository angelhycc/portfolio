/**
 * Project 1
 * EECS 370 LC-2K Instruction-level simulator
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define NUMMEMORY 65536 /* maximum number of words in memory */
#define NUMREGS 8 /* number of machine registers */
#define MAXLINELENGTH 1000

typedef struct stateStruct {
    int pc;
    int mem[NUMMEMORY];
    int reg[NUMREGS];
    int numMemory;
} stateType;

void printState(stateType *);
int convertNum(int);

int
main(int argc, char *argv[])
{
    char line[MAXLINELENGTH];
    stateType state;
    FILE *filePtr;

    if (argc != 2) {
        printf("error: usage: %s <machine-code file>\n", argv[0]);
        exit(1);
    }

    filePtr = fopen(argv[1], "r");
    if (filePtr == NULL) {
        printf("error: can't open file %s", argv[1]);
        perror("fopen");
        exit(1);
    }

    /* read the entire machine-code file into memory */
    for (state.numMemory = 0; fgets(line, MAXLINELENGTH, filePtr) != NULL;
            state.numMemory++) {

        if (sscanf(line, "%d", state.mem+state.numMemory) != 1) {
            printf("error in reading address %d\n", state.numMemory);
            exit(1);
        }
        printf("memory[%d]=%d\n", state.numMemory, state.mem[state.numMemory]);
    }
    // set all registers to 0
    for (int i = 0; i < NUMREGS; ++i){
        state.reg[i] = 0;
    }
//    printState(&state);
    //starting from pc 1
    int totalInstructions = 0;
    while (state.pc <= state.numMemory){
        ++totalInstructions;
        printState(&state);
        int mc = state.mem[state.pc];
        int opcode = mc >> 22;
        if (opcode == 0){ //add
            int reg1 = (mc & 0x0380000) >> 19;
            int reg2 = (mc & 0x0070000) >> 16;
            int destreg = mc & 0x000FFFF;
            state.reg[destreg] = state.reg[reg1] + state.reg[reg2];
        } else if (opcode == 1){ //nor
            int reg1 = (mc & 0x0380000) >> 19;
            int reg2 = (mc & 0x0070000) >> 16;
            int destreg = mc & 0x000FFFF;
            int first = ~state.reg[reg1];
            int second = ~state.reg[reg2];
            state.reg[destreg] = first & second;
        } else if (opcode == 2){ //lw
            int reg1 = (mc & 0x0380000) >> 19;
            int reg2 = (mc & 0x0070000) >> 16;
            int offset = convertNum(mc & 0x000FFFF);
            state.reg[reg2] = state.mem[state.reg[reg1] + offset];
        } else if (opcode == 3){ // sw
            int reg1 = (mc & 0x0380000) >> 19;
            int reg2 = (mc & 0x0070000) >> 16;
            int offset = convertNum(mc & 0x000FFFF);
            state.mem[state.reg[reg1] + offset] = state.reg[reg2];
        } else if (opcode == 4){ // beq
            int reg1 = (mc & 0x0380000) >> 19;
            int reg2 = (mc & 0x0070000) >> 16;
            int offset = convertNum(mc & 0x000FFFF);
            if (state.reg[reg1] == state.reg[reg2]){
                state.pc = state.pc + offset;
            }
        } else if (opcode == 5){ //jalr
            int reg1 = (mc & 0x0380000) >> 19;
            int reg2 = (mc & 0x0070000) >> 16;
            state.reg[reg2] = state.pc + 1;
            state.pc = state.reg[reg1] - 1;
        } else if (opcode == 6){ //halt
            state.pc ++;
            printf("machine halted\n");
            break;
        } else if (opcode == 7){ //noop
            //do nothing
        } else {
            printf("invalid opcode\n");
            exit (1);
        }
        state.pc ++;
    }
    printf("total of %d instructions executed\n", totalInstructions);
    printf("final state of machine:\n");
    printState(&state);
    return(0);
}

void
printState(stateType *statePtr)
{
    int i;
    printf("\n@@@\nstate:\n");
    printf("\tpc %d\n", statePtr->pc);
    printf("\tmemory:\n");
    for (i=0; i<statePtr->numMemory; i++) {
              printf("\t\tmem[ %d ] %d\n", i, statePtr->mem[i]);
    }
    printf("\tregisters:\n");
    for (i=0; i<NUMREGS; i++) {
              printf("\t\treg[ %d ] %d\n", i, statePtr->reg[i]);
    }
    printf("end state\n");
}

int
convertNum(int num)
{
    /* convert a 16-bit number into a 32-bit Linux integer */
    if (num & (1<<15) ) {
        num -= (1<<16);
    }
    return(num);
}

