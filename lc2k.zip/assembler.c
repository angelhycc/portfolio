    /**
 * Project 1 
 * Assembler code fragment for LC-2K 
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>

#define MAXLINELENGTH 1000

int readAndParse(FILE *, char *, char *, char *, char *, char *);
int isNumber(char *);

int main(int argc, char *argv[])
{
    char *inFileString, *outFileString;
    FILE *inFilePtr, *outFilePtr;
    char label[MAXLINELENGTH], opcode[MAXLINELENGTH], arg0[MAXLINELENGTH],
            arg1[MAXLINELENGTH], arg2[MAXLINELENGTH];
    
    if (argc != 3) {
        printf("error: usage: %s <assembly-code-file> <machine-code-file>\n", argv[0]);
        exit(1);
    }

    inFileString = argv[1];
    outFileString = argv[2];

    inFilePtr = fopen(inFileString, "r");
    if (inFilePtr == NULL) {
        printf("error in opening %s\n", inFileString);
        exit(1);
    }
    outFilePtr = fopen(outFileString, "w");
    if (outFilePtr == NULL) {
        printf("error in opening %s\n", outFileString);
        exit(1);
    }

    /* here is an example for how to use readAndParse to read a line from
        inFilePtr */
//    if (! readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2) ) {
//        exit(0);
//        /* reached end of file */
//    }
    struct pair {
        int address;
        char label[];
    };
    struct pair labelArr[MAXLINELENGTH] ;
    int counter = 0;
    int numLabels = 0;
    while(0!=readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2)) {
        for (int i = 0; i < numLabels; i += 11){
            if(0 == strcmp(labelArr[i].label,label)){
                printf("duplicate labels");
                exit (1);
            }
        }
        if (0!=strcmp(label, "")){
            labelArr[numLabels].address = counter;
            strcpy(labelArr[numLabels].label, label);
            numLabels += 11;
        }
        ++counter;
    }
    
    rewind(inFilePtr);
    
    int pc = 0;
    while(0!=readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2)) {
        int output = 0;
        if (0 == strcmp(opcode, "add")){
            output = atoi(arg0) << 19 | atoi(arg1)<<16 | atoi(arg2);
        } else if (0==strcmp(opcode, "nor")){
            output = 1 <<22 | atoi(arg0) << 19 |atoi(arg1) << 16 | atoi(arg2);
        } else if (0==strcmp(opcode, "lw")){
            int offset = 0;
            if (isNumber(arg2)){
                offset = atoi(arg2);
            } else {
                bool exists = false;
                for (int i = 0; i < numLabels; i+=11){
                    if (0 == strcmp(labelArr[i].label, arg2)){
                        offset = labelArr[i].address;
                        exists = true;
                        break;
                    }
                }
                if (!exists){
                    printf("undefined labels");
                    exit(1);
                }
            }
            if (offset > 32767 || offset < -32768){
                printf("invalid offset");
                exit(1);
            }
            offset = (offset & 0xffff);
            output = 2 << 22 | atoi(arg0) << 19 | atoi(arg1) << 16 | offset;
        } else if (0 == strcmp(opcode, "sw")){
            int offset = 0;
            if (isNumber(arg2)){
                offset = atoi(arg2);
            } else {
                bool exists = false;
                for (int i = 0; i < numLabels; i+=11){
                    if (0 == strcmp(labelArr[i].label, arg2)){
                        offset = labelArr[i].address;
                        exists = true;
                        break;
                    }
                }
                if (!exists){
                    printf("undefined labels");
                    exit(1);
                }
            }
            if (offset > 32767 || offset < -32768){
                printf("invalid offset");
                exit(1);
            }
            offset = (offset & 0xffff);
            output = 3 << 22 | atoi(arg0) << 19 | atoi(arg1) << 16 | offset;
        } else if (0==strcmp(opcode, "beq")){
            
            int offset = 0;
            if (isNumber(arg2)){
                offset = atoi(arg2);
            } else {
                bool exists = false;
                for (int i = 0; i < numLabels; i+=11){
                    if (0 == strcmp(labelArr[i].label, arg2)){
                        offset = labelArr[i].address - pc - 1;
                        exists = true;
                        break;
                    }
                }
                if (!exists){
                    printf("undefined labels");
                    exit(1);
                }
            }
            if (offset > 32767 || offset < -32768){
                printf("invalid offset");
                exit(1);
            }
            offset = (offset & 0xffff);
            output = 4 << 22 | atoi(arg0) << 19 | atoi(arg1) << 16 | offset;
        } else if (0==strcmp(opcode, "jalr")){
            output = 5 << 22 | atoi(arg0) << 19 | atoi(arg1) << 16;
        } else if (0==strcmp(opcode, "halt")){
            output = 6 << 22;
        } else if (0==strcmp(opcode, "noop")){
            output = 7 << 22;
        } else if (0==strcmp(opcode, ".fill")){
            int offset = 0;
            if(isNumber(arg0)){
                offset = atoi(arg0);
            } else {
                bool exists = false;
                for (int i = 0; i < numLabels; i+=11){
                    if (0==strcmp(labelArr[i].label, arg0)){
                        offset = labelArr[i].address;
                        exists = true;
                        break;
                    }
                }
                if (!exists){
                    printf("undefined labels");
                    exit(1);
                }
            }
            if (offset > 32767 || offset < -32768){
                printf("invalid offset");
                exit(1);
            }
            output = offset;
        } else {
            printf("undefined opcode ");
            exit(1);
        }
        fprintf(outFilePtr,"%d\n", output);
        ++pc;
    }
    return(0);
}

/*
 * Read and parse a line of the assembly-language file.  Fields are returned
 * in label, opcode, arg0, arg1, arg2 (these strings must have memory already
 * allocated to them).
 *
 * Return values:
 *     0 if reached end of file
 *     1 if successfully read
 *
 * exit(1) if line is too long.
 */
int
readAndParse(FILE *inFilePtr, char *label, char *opcode, char *arg0,
        char *arg1, char *arg2)
{
    char line[MAXLINELENGTH];

    /* delete prior values */
    label[0] = opcode[0] = arg0[0] = arg1[0] = arg2[0] = '\0';

    /* read the line from the assembly-language file */
    if (fgets(line, MAXLINELENGTH, inFilePtr) == NULL) {
        /* reached end of file */
        return(0);
    }

    /* check for line too long (by looking for a \n) */
    if (strchr(line, '\n') == NULL) {
        /* line too long */
        printf("error: line too long\n");
        exit(1);
    }

    /* is there a label? */
    char *ptr = line;
    if (sscanf(ptr, "%[^\t\n\r ]", label)) {
        /* successfully read label; advance pointer over the label */
        ptr += strlen(label);
    }

    /*
     * Parse the rest of the line.  Would be nice to have real regular
     * expressions, but scanf will suffice.
     */
    
    sscanf(ptr, "%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]",
        opcode, arg0, arg1, arg2);
    return(1);
}

int
isNumber(char *string)
{
    /* return 1 if string is a number */
    int i;
    return( (sscanf(string, "%d", &i)) == 1);
}


